import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormArray } from '../../../node_modules/@angular/forms';
import { User, HttpService } from '../service/http.service';

@Component({
  selector: 'app-member',
  templateUrl: './member.component.html',
  styleUrls: ['./member.component.css']
})
export class MemberComponent implements OnInit {

  
  user: User = new User("","","","","");

  constructor(
    private httpService: HttpService
  ) { }
 
  ngOnInit() {
  }

  addMember(): void {
    this.httpService.createMember(this.user)
        .subscribe( data => {
          alert("Member added successfully.");
        });

  };
}
