import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SucregistrationComponent } from './sucregistration.component';

describe('SucregistrationComponent', () => {
  let component: SucregistrationComponent;
  let fixture: ComponentFixture<SucregistrationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SucregistrationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SucregistrationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
