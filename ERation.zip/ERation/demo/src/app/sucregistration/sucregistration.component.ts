import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sucregistration',
  templateUrl: './sucregistration.component.html',
  styleUrls: ['./sucregistration.component.css']
})
export class SucregistrationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
