import { Component, OnInit } from '@angular/core';
import { Validators,FormBuilder,FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthenticationService } from '../service/authentication.service';
import { HttpService, User } from '../service/http.service';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

 user :User=new User("","","","","");
  
  ngOnInit() {
  }
  registrationForm: FormGroup;
  constructor(private router: Router,private regService: HttpService,private formBuilder: FormBuilder) { 
    this.registrationForm=this.formBuilder.group({
      // username:['',[Validators.required,Validators.minLength(3)]],
      password:['',[Validators.required,Validators.minLength(8)]],
      address:['',[Validators.required,Validators.minLength(10)]],
      // email:['',[Validators.required,Validators.email]],
      phonenumber:['',[Validators.required,Validators.min(1000000000),Validators.max(9999999999)]],
      citizennumber:['',[Validators.required,Validators.minLength(2)]]

  });
    
}
checkRegistration(){
   //this.regService.setauth(this.username)
      this.regService.newUserRegistration(this.user)
      .subscribe( data =>{alert("User registered successfully.");})                      //
       this.router.navigate(['/sucregistration'])
  //     this.regService.isUserLoggedIn
    // } else
      // this.invalidLogin = true
}
}
