import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
export class User{
  constructor(
    public username:string,
    public password:string,
    public address:string,
    public phonenumber:string,
    public citizennumber:string
  ){}
}

@Injectable({
  providedIn: 'root'
})
export class HttpService {

  constructor(private httpClient:HttpClient) {}
  getEmployees()
  {
    let basicString=this.getHeaders();

    let headers=new HttpHeaders(
      {Authorization:basicString}
    );
    console.log("test call");
    return this.httpClient.get<User[]>('http://localhost:8080/',{headers});
  }
  createMember(user){
    return this.httpClient.post<User>("http://localhost:8080/", user);
  }
  deleteMember(user){
    return this.httpClient.delete<User>("http://localhost:8080/" + "/"+ user.citizennumber);
  }
  newUserRegistration(user){
    return this.httpClient.post<User>("http://localhost:9090/ticket/bookTickets", user);
  }
  viewUserdetails(){
    
  }

  getHeaders(){
    let username='admin'
    let password='password'
  
    let  basicString='Basic '+window.btoa(username + ':' + password)
    return basicString;
  }
}
